﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YF.Model
{
    public class book
    {
        private int bookid;

        public int Bookid
        {
            get { return bookid; }
            set { bookid = value; }
        }

        private string bookname;

        public string Bookname
        {
            get { return bookname; }
            set { bookname = value; }
        }

        private string bookauthor;

        public string Bookauthor
        {
            get { return bookauthor; }
            set { bookauthor = value; }
        }

        private float bookprice;

        public float Bookprice
        {
            get { return bookprice; }
            set { bookprice = value; }
        }

        private string booktype;

        public string Booktype
        {
            get { return booktype; }
            set { booktype = value; }
        }

        private int bookissue;

        public int Bookissue
        {
            get { return bookissue; }
            set { bookissue = value; }
        }
    }
}
