﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YF.Model
{
    public class borrow
    {
        private int isbookid;

        public int Isbookid
        {
            get { return isbookid; }
            set { isbookid = value; }
        }

        private string isbookname;

        public string Isbookname
        {
            get { return isbookname; }
            set { isbookname = value; }
        }

        private string isname;

        public string Isname
        {
            get { return isname; }
            set { isname = value; }
        }

        private int isid;

        public int Isid
        {
            get { return isid; }
            set { isid = value; }
        }

        private DateTime isdate;

        public DateTime Isdate
        {
            get { return isdate; }
            set { isdate = value; }
        }
    }
}
