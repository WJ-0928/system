﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class bookadd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        YF.Model.book book = new YF.Model.book();
        book.Bookname = this.bookname.Text;
        book.Bookauthor = this.bookauthor.Text;
        book.Bookprice = int.Parse(this.bookprice.Text);
        book.Booktype = this.booktype.Text;
        book.Bookissue = int.Parse(this.bookissue.Text);

        if (YF.BLL.User.Search(this.bookname.Text) == false)
        {
            YF.JsHelper.AlertAndRedirect("本书已存在！", "bookadd.aspx");
        }


        //判断是否注册成功
        if (YF.BLL.book.addbook(book) == true)
        {
            YF.JsHelper.AlertAndRedirect("添加成功！", "admin.aspx");//跳转到指定页面
        }
        else
        {
            YF.JsHelper.AlertAndRedirect("添加失败！", "bookadd.aspx");
        }

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        YF.JsHelper.Redirect("admin.aspx");
    }
}