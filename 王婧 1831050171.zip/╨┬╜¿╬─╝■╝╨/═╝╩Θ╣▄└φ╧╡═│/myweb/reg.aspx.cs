﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using YF;

public partial class reg : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        YF.Model.User user = new YF.Model.User();
        user.Username = this.username.Text;
        user.Password = this.password.Text;
        user.Name = this.name.Text;
        user.Sex = int.Parse(this.sex.Text);//字符串类型转换成int型
        user.Moblie = this.moblie.Text;
        user.Email= this.email.Text;
        user.Qq = this.qq.Text;
        user.State = 1;
        user.Adddate = DateTime.Now;
        user.Type = int.Parse(this.type.Text);

        if (YF.BLL.User.Search(this.username.Text)==false)
        {
            YF.JsHelper.AlertAndRedirect("用户名已存在！", "reg.aspx");
        }


        //判断是否注册成功
        if (YF.BLL.User.add(user) == true)
        {
            YF.JsHelper.AlertAndRedirect("注册成功！", "login.aspx");//跳转到指定页面
        }
        else
        {
            YF.JsHelper.AlertAndRedirect("注册失败！", "reg.aspx");
        }

    }
}