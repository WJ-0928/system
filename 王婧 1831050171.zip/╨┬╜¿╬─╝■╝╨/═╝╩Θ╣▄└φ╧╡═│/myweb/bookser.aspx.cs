﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class bookser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string bookid = Request.QueryString["bookid"];
            YF.Model.book book = YF.BLL.book.Getbook(int.Parse(bookid));
            //book.Bookname = this.bookname.Text;
            //book.Bookauthor = this.bookauthor.Text;
            //book.Bookprice = int.Parse(this.bookprice.Text);
            //book.Booktype = this.booktype.Text;
            //book.Bookissue = int.Parse(this.bookissue.Text);
            this.bookname.Text = book.Bookname;
            this.bookauthor.Text = book.Bookauthor;
            this.bookprice.Text = book.Bookprice.ToString();
            this.booktype.Text = book.Booktype;
            this.bookissue.Text = book.Bookissue.ToString();
            this.bookid.Value = book.Bookid.ToString();
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        YF.Model.book book = new YF.Model.book();
        book.Bookname = this.bookname.Text;
        book.Bookauthor = this.bookauthor.Text;
        book.Bookprice = int.Parse(this.bookprice.Text);
        book.Booktype = this.booktype.Text;
        book.Bookissue = int.Parse(this.bookissue.Text);
        book.Bookid = int.Parse(this.bookid.Value);
        if (YF.BLL.book.updatebook(book) == true)
        {
            YF.JsHelper.AlertAndRedirect("修改成功！", "admin.aspx");
        }
        else
        {
            YF.JsHelper.AlertAndRedirect("修改失败！", "bookser.aspx");
        }
    }
}