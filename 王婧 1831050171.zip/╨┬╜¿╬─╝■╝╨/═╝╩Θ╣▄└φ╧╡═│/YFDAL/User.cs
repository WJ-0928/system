﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

//数据库访问层
namespace YF.DAL
{
    /// <summary>
    /// 用户数据访问类
    /// </summary>
    public class User
    {
        //添加用户
        public static bool add(YF.Model.User user) 
        {

            bool result = false;

            string strsql = "insert into t_user (username,password,name,sex,moblie,email,qq,state,adddate,type) values ('" + user.Username + "','" + user.Password + "','" + user.Name + "'," + user.Sex + ",'" + user.Moblie + "','" + user.Email + "','" + user.Qq + "'," + user.State + ",'" + user.Adddate + "'," + user.Type + ")";

            int i = YF.MsSqlHelper.YFMsSqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }


        //登录
        public static bool login(string username,string password)
        {
            bool result = false;

            string strsql = "select * from t_user where username='" + username + "' and password='" + password + "'";
            
            DataTable dataTable = YF.MsSqlHelper.YFMsSqlHelper.Query(strsql).Tables[0];
            if (dataTable.Rows.Count != 0)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        //查看所有用户信息
        public static List<YF.Model.User> List()
        {
            string strsql = "select * from t_user order by id asc";

            DataTable dataTable = YF.MsSqlHelper.YFMsSqlHelper.Query(strsql).Tables[0];
            return Dttolist(dataTable);
        }

        public static List<YF.Model.User> Dttolist(DataTable dataTable)
        {
            List<YF.Model.User> list = new List<Model.User>();

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                YF.Model.User user = new Model.User();
                user.Id = int.Parse(dataTable.Rows[i]["id"].ToString());
                user.Username = dataTable.Rows[i]["username"].ToString();
                user.Password = dataTable.Rows[i]["password"].ToString();
                user.Name = dataTable.Rows[i]["name"].ToString();
                user.Sex = int.Parse(dataTable.Rows[i]["sex"].ToString());
                user.Moblie = dataTable.Rows[i]["moblie"].ToString();
                user.Email = dataTable.Rows[i]["email"].ToString();
                user.Qq = dataTable.Rows[i]["qq"].ToString();
                user.State = int.Parse(dataTable.Rows[i]["state"].ToString());
                user.Adddate = DateTime.Parse(dataTable.Rows[i]["adddate"].ToString());
               
                list.Add(user);
            }

            return list;
        }

        //修改
        public static bool update(YF.Model.User user)
        {
            bool result = false;

            string strsql = "update t_user set password='" + user.Password + "',name='" + user.Name + "',sex=" + user.Sex + ",moblie='" + user.Moblie + "',email='" + user.Email + "',qq='" + user.Qq + "',state=" + user.State + " where id="+user.Id+"";

            int i = YF.MsSqlHelper.YFMsSqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }
        //通过id查看用户信息
        public static YF.Model.User GetUser(int id)
        {
            YF.Model.User user = new Model.User();

            string strsql = "select * from t_user where id=" + id + "";

            DataTable dataTable = YF.MsSqlHelper.YFMsSqlHelper.Query(strsql).Tables[0];
            if (dataTable.Rows.Count != 0)
            {
                user.Id = int.Parse(dataTable.Rows[0]["id"].ToString());
                user.Username = dataTable.Rows[0]["username"].ToString();
                user.Password = dataTable.Rows[0]["password"].ToString();
                user.Name = dataTable.Rows[0]["name"].ToString();
                user.Sex = int.Parse(dataTable.Rows[0]["sex"].ToString());
                user.Moblie = dataTable.Rows[0]["moblie"].ToString();
                user.Email = dataTable.Rows[0]["email"].ToString();
                user.Qq = dataTable.Rows[0]["qq"].ToString();
                user.State = int.Parse(dataTable.Rows[0]["state"].ToString());
                user.Adddate = DateTime.Parse(dataTable.Rows[0]["adddate"].ToString());
                
            }

            return user;
        }
        public static YF.Model.User GetUser(string username)
        {
            YF.Model.User user = new Model.User();

            string strsql = "select * from t_user where username='" + username + "'";

            DataTable dataTable = YF.MsSqlHelper.YFMsSqlHelper.Query(strsql).Tables[0];
            if (dataTable.Rows.Count != 0)
            {
                user.Id = int.Parse(dataTable.Rows[0]["id"].ToString());
                user.Username = dataTable.Rows[0]["username"].ToString();
                user.Password = dataTable.Rows[0]["password"].ToString();
                user.Name = dataTable.Rows[0]["name"].ToString();
                user.Sex = int.Parse(dataTable.Rows[0]["sex"].ToString());
                user.Moblie = dataTable.Rows[0]["moblie"].ToString();
                user.Email = dataTable.Rows[0]["email"].ToString();
                user.Qq = dataTable.Rows[0]["qq"].ToString();
                user.State = int.Parse(dataTable.Rows[0]["state"].ToString());
                user.Adddate =DateTime.Parse(dataTable.Rows[0]["adddate"].ToString());
               
            }

            return user;
        }
           

        //删除
        public static bool del(int id)
        {
            bool result = false;

            string strsql = "delete from t_user where id='" + id + "'";

            int i = YF.MsSqlHelper.YFMsSqlHelper.ExecuteSql(strsql);
            if (i > 0)
            {
                result = true;
            }
            return result;
        }
        //查询用户存在不存在
        public static bool Search(string username)
        {
            bool result = false;

            string strsql = "select * from t_user where username='" + username + "'";

            DataTable dataTable = YF.MsSqlHelper.YFMsSqlHelper.Query(strsql).Tables[0];
            if (dataTable.Rows.Count == 0)//没有查到记录，用户名可用
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }
    }
}
